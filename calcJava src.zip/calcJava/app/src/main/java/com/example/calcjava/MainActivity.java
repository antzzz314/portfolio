package com.example.calcjava;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import org.w3c.dom.Text;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity  implements View.OnClickListener {
    static ArrayList<String> calc = new ArrayList<>();
    static ArrayList<String> result = new ArrayList<>();
    int mId[] = {R.id.num0, R.id.num1, R.id.num2, R.id.num3,
            R.id.num4, R.id.num5, R.id.num6, R.id.num7,
            R.id.num8, R.id.num9, R.id.add, R.id.sub,
            R.id.mul, R.id.div, R.id.per, R.id.equal,
            R.id.point, R.id.del, R.id.sign, R.id.clear};
    Button button[] = new Button[mId.length];
    private int beforeStatus = 0;
    private final int plus = 10;
    private final int minus = 11;
    private final int mul = 12;
    private final int div = 13;
    private final int per = 14;
    private final int equal = 15;
    private final int point = 16;
    private final int del = 17;
    private final int sign = 18;
    private final int clear = 19;
    private TextView text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text = findViewById(R.id.fomula);
        for (int i = 0; i < mId.length; i++) {
            button[i] = findViewById(mId[i]);
            button[i].setOnClickListener(this);
        }
    }

    public void onClick(View view) {
        for (int i = 0; i < mId.length; i++) {
            if (view.equals(button[i])) {
                String nowValue = text.getText().toString();
                //text.setText(String.valueOf(i));
                if (i == clear) {
                    text.setText("");
                    calc.clear();
                    result.clear();
                    beforeStatus = 19;
                }else if (i == sign && nowValue.length() > 0 && !(9<beforeStatus && beforeStatus<16)) {
                    nowValue = String.valueOf(Integer.parseInt(nowValue)*-1);
                    text.setText(nowValue);
                    beforeStatus = 18;
                }else if (i == del) {
                    text.setText("");
                    beforeStatus = 17;
                }else if (i == point && nowValue.length() > 0) {
                    if(nowValue.substring(nowValue.length() - 1).matches("[0-9]")){
                        nowValue = nowValue + ".";
                        text.setText(nowValue);
                    }else{return;}
                    beforeStatus = 16;
                }else if (i == equal && nowValue.length() > 0) {
                    nowValue = checkdisplay(nowValue);
                    calc.add(nowValue);
                    //if (calc.size()<=result.size()){
                    //result.remove(-1);
                    //}
                    double ans = calc();
                    text.setText(Double.toString(ans));
                    calc.clear();
                    result.clear();
                    beforeStatus = 15;
                }else if (i == per && nowValue.length() > 0 && !(9<beforeStatus && beforeStatus<15)) {
                    calc.add(nowValue);
                    result.add("%");
                    text.setText("%");
                    beforeStatus = 14;
                }else if (i == div && nowValue.length() > 0 && !(9<beforeStatus && beforeStatus<15)) {
                    calc.add(nowValue);
                    result.add("/");
                    text.setText("/");
                    beforeStatus = 13;
                } else if (i == mul && nowValue.length() > 0 && !(9<beforeStatus && beforeStatus<15)) {
                    calc.add(nowValue);
                    text.setText("*");
                    result.add("*");
                    beforeStatus = 12;
                } else if (i == minus && nowValue.length() > 0 && !(9<beforeStatus && beforeStatus<15)) {
                    calc.add(nowValue);
                    text.setText("-");
                    result.add("-");
                    beforeStatus = 11;
                } else if (i == plus && nowValue.length() > 0 && !(9<beforeStatus && beforeStatus<15)){
                    calc.add(nowValue);
                    text.setText("+");
                    result.add("+");
                    beforeStatus = 10;
                } else if (i < 10) {
                    nowValue = checkdisplay(nowValue);
                    if (nowValue.equals("0") && i == 0) {
                        return;
                    } else if (nowValue.equals("0") && i != 0) {
                        nowValue = "";
                    }
                    nowValue = nowValue + i;
                    text.setText(nowValue);
                    beforeStatus = i;
                }
                break;
            }
        }
    }

    private String checkdisplay(String val) {
        if (beforeStatus == 10 || beforeStatus == 11
                || beforeStatus == 12 || beforeStatus == 13 || beforeStatus == 14) {
            text.setText("");
            return "0";
        }
        return val;
    }

    private double calc() {
        if (calc.size() == 0) {
            return 0.0;
        }
        if (calc.size() == 1) {
            return Double.parseDouble(calc.get(0));
        }
        double passive = Double.parseDouble(calc.get(0));
        double active;
        int j = 0;
        if (calc.size()<=result.size()){
            result.remove(result.size()-1);
        }
        for (int i = 1; i < calc.size(); i++) {
            active = Double.parseDouble(calc.get(i));
            if (result.get(j).equals("+")) {
                passive += active;
            } else if(result.get(j).equals("-")){
                passive -= active;
            } else if(result.get(j).equals("*")){
                passive *= active;
            } else if(result.get(j).equals("/")){
                passive /= active;
            }else if(result.get(j).equals("%")){
                passive %= active;
            }
            j++;
        }//text.setText(calc.get(0));
        return passive;
    }
}